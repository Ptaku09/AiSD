package ex2;

public class Main2 {
    public static void main(String[] args) {
        LongestCommonSubsequence.lcs("abbaa", "bababab");
        LongestCommonSubsequence.lcs("aa", "bb");
        LongestCommonSubsequence.lcs("abcdef", "abcdef");
        LongestCommonSubsequence.lcs("asdzcxsadzcs", "axcasxzcsdasdx");
    }
}
