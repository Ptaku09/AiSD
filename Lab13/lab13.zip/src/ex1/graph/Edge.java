package ex1.graph;

public record Edge(Node source, Node destination, int weight) {
}
