package ex2;

import java.util.Random;

public class Main2 {
    public static void main(String[] args) {
        Random random = new Random();
        int[] array = createArray(5000);
        int[] array2 = createArray(5000);
        int comparisonsLinear = 0;
        int comparisonsBinary = 0;
        int foundedLinear = 0;
        int foundedBinary = 0;

        Searching searching = new Searching(array, array2);

        for (int i = 0; i < 1000; i++) {
            System.out.println(searching.linearSearch(random.nextInt(1, 10000)));
            System.out.println(searching.binarySearch(random.nextInt(1, 10000)));
        }
    }

    private static int[] createArray(int n) {
        Random random = new Random();
        int[] result = new int[n];

        for (int i = 0; i < n; i++)
            result[i] = random.nextInt(1, 10000);

        return result;
    }
}
