package ex2;

import ex1.Heap;

public class Searching {
    private int[] arr1;
    private int[] arr2;

    public Searching(int[] arr1, int[] arr2) {
        this.arr1 = arr1;
        this.arr2 = arr2;
    }

    public int linearSearch(int key) {
        for (int i = 0; i < arr1.length; i++)
            if (arr1[i] == key)
                return i;

        return -1;
    }

    public int binarySearch(int key) {
        int left = 0;
        int right = arr2.length - 1;

        // We will use heap from ex1 to sort the array
        Heap heap = new Heap(arr2);
        heap.sort();

        while (left <= right) {
            int mid = (left + right) / 2;

            if (key < arr2[mid]) {
                right = mid - 1;
            } else if (key > arr2[mid]) {
                left = mid + 1;
            } else {
                return mid;
            }
        }

        return -1;
    }
}
