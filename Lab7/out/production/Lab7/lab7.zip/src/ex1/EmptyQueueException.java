package ex1;

public class EmptyQueueException extends Exception {
    public EmptyQueueException() {
        super("Queue is empty");
    }
}
