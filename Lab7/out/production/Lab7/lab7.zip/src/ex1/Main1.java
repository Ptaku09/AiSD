package ex1;

public class Main1 {
    public static void main(String[] args) throws EmptyQueueException, FullQueueException {
        HeapPriorityQueue priorityQueue = new HeapPriorityQueue();

        priorityQueue.enqueue(4);
        priorityQueue.enqueue(5);
        priorityQueue.enqueue(10);
        priorityQueue.enqueue(7);
        priorityQueue.enqueue(6);
        priorityQueue.enqueue(9);
        priorityQueue.enqueue(12);
        priorityQueue.enqueue(1);

        priorityQueue.display();

        priorityQueue.changePriority(0, 2);
        priorityQueue.display();

        priorityQueue.deleteElement(2);
        priorityQueue.display();

        priorityQueue.deleteElement(0);
        priorityQueue.display();

        int res = priorityQueue.dequeue();
        System.out.println("Dequeued: " + res);
        priorityQueue.display();

        res = priorityQueue.dequeue();
        System.out.println("Dequeued: " + res);

        res = priorityQueue.dequeue();
        System.out.println("Dequeued: " + res);

        res = priorityQueue.dequeue();
        System.out.println("Dequeued: " + res);

        res = priorityQueue.dequeue();
        System.out.println("Dequeued: " + res);

        res = priorityQueue.dequeue();
        System.out.println("Dequeued: " + res);

        priorityQueue.display();


        System.out.println("------");
        Heap heap = new Heap(new int[]{2, 4, 6, 0, 8, 12, 321, 4, 6});
        heap.sort();

        heap.display();
    }
}
