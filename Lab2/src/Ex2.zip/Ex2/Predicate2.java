package Ex2;

public interface Predicate2<T> {
    boolean accept(T arg);
}
