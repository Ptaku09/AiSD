package Ex1;

public interface Predicate<T> {
    boolean accept(T arg);
}
