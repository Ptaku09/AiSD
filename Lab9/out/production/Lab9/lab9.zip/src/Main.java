import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();
        Scanner scanner = new Scanner(System.in);
        int n = 1;

        while (n != 0) {
            System.out.println("1. Insert element");
            System.out.println("2. Preorder walk");
            System.out.println("3. Inorder walk");
            System.out.println("4. Postorder walk");
            System.out.println("5. Search element");
            System.out.println("6. Delete element");
            System.out.println("7. Get height");
            System.out.println("8. Get number of nodes");
            System.out.println("9. Get number of leaves");
            System.out.println("10. Display by level");
            System.out.println("11. Find successor");
            System.out.println("12. Find predecessor");
            System.out.println("13. Find minimum");
            System.out.println("14. Find maximum");
            System.out.println("15. Print tree");
            System.out.println("0. Exit");
            System.out.println();
            System.out.println("Enter your choice: ");

            n = scanner.nextInt();
            System.out.println();

            switch (n) {
                case 1 -> {
                    System.out.println("Enter the element: ");
                    int element = scanner.nextInt();
                    bst.insert(element);
                }

                case 2 -> bst.preOrderWalk();

                case 3 -> bst.inOrderWalk();

                case 4 -> bst.postOrderWalk();

                case 5 -> {
                    System.out.println("Enter the element: ");
                    int element = scanner.nextInt();
                    System.out.printf("Founded element: " + bst.find(element));
                }

                case 6 -> {
                    System.out.println("Enter the element: ");
                    int element = scanner.nextInt();
                    bst.delete(element);
                }

                case 7 -> System.out.println("Height: " + bst.getHeight());

                case 8 -> System.out.println("Number of nodes: " + bst.getNumberOfNodes());

                case 9 -> System.out.println("Number of leaves: " + bst.getNumberOfLeafNodes());

                case 10 -> bst.displayByLevel();

                case 11 -> {
                    System.out.println("Enter the element: ");
                    int element = scanner.nextInt();
                    bst.successor(element);
                    System.out.println("Successor: " + bst.successor(element));
                    System.out.println();
                }

                case 12 -> {
                    System.out.println("Enter the element: ");
                    int element = scanner.nextInt();
                    bst.predecessor(element);
                    System.out.println("Predecessor: " + bst.predecessor(element));
                    System.out.println();
                }

                case 13 -> {
                    System.out.println("Minimum: " + bst.getMin());
                    System.out.println();
                }

                case 14 -> {
                    System.out.println("Maximum: " + bst.getMax());
                    System.out.println();
                }

                case 15 -> bst.drawTree();

                default -> n = 20;
            }
        }
    }
}
