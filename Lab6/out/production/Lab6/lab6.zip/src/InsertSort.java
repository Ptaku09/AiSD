public class InsertSort {
    public static void sort(int[] tab) {
        int compares = 0;
        int swaps = 0;

        for (int i = 0; i < tab.length; i++) {
            for (int j = i; j > 0; j--) {
                if (tab[j] < tab[j - 1]) {
                    int temp = tab[j];
                    tab[j] = tab[j - 1];
                    tab[j - 1] = temp;
                    swaps += 3;
                }

                compares++;
            }
        }

        System.out.println("Insert sort: ");
        System.out.println("Compares: " + compares);
        System.out.println("Swaps: " + swaps);
        System.out.println();
    }
}
