import java.util.Arrays;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        int[] arraysLength = {8, 32, 128, 512};

        System.out.println("Random");
        System.out.println("-----------------------");

        for (int length : arraysLength) {
            int[] array1 = createArray(length);

            run(array1);
        }

        System.out.println("Sorted backwards");
        System.out.println("-----------------------");

        for (int length : arraysLength) {
            int[] array1 = createArray(length);

            run(array1);
        }

        for (int length : arraysLength) {
            int[] array1 = createArray(length);
            Arrays.sort(array1);
            int[] array2 = duplicateArray(array1);
            int[] array3 = duplicateArray(array1);
            int[] array4 = duplicateArray(array1);


            printArray(array1);

            InsertSort.sort(array1);
            SelectSort.sort(array2);
            MergeSort.sort(array3);
            QuickSort.sort(array4);

            printArray(array3);
        }

        System.out.println("Sorted");
        System.out.println("-----------------------");
    }

    private static void run(int[] array1) {
        int[] array2 = duplicateArray(array1);
        int[] array3 = duplicateArray(array1);
        int[] array4 = duplicateArray(array1);


        printArray(array1);

        InsertSort.sort(array1);
        SelectSort.sort(array2);
        MergeSort.sort(array3);
        QuickSort.sort(array4);

        printArray(array3);
    }

    private static void printArray(int[] arr) {
        for (int i : arr)
            System.out.print(i + " ");

        System.out.println();
    }

    private static int[] duplicateArray(int[] arr) {
        int[] result = new int[arr.length];
        System.arraycopy(arr, 0, result, 0, arr.length);

        return result;
    }

    private static int[] createArray(int n) {
        Random random = new Random();
        int[] result = new int[n];

        for (int i = 0; i < n; i++) {
            result[i] = random.nextInt(1, 1000);
        }

        return result;
    }
}
