public class MergeSort {
    private static int compares = 0;
    private static int swaps = 0;

    public static void sort(int[] tab) {
        mergeSort(tab, tab.length);

        System.out.println("Merge sort: ");
        System.out.println("Compares: " + compares);
        System.out.println("Swaps: " + swaps);
        System.out.println();
    }

    private static void mergeSort(int[] tab, int n) {
        if (n < 2)
            return;

        int mid = n / 2;
        int[] left = new int[mid];
        int[] right = new int[n - mid];

        for (int i = 0; i < mid; i++) {
            left[i] = tab[i];
        }

        for (int i = mid; i < n; i++) {
            right[i - mid] = tab[i];
        }

        mergeSort(left, mid);
        mergeSort(right, n - mid);
        merge(tab, left, right, mid, n - mid);
    }

    private static void merge(int[] tab, int[] left, int[] right, int l, int r) {
        int i = 0, j = 0, k = 0;
        while (i < l && j < r) {
            if (left[i] <= right[j]) {
                tab[k++] = left[i++];
            } else {
                tab[k++] = right[j++];
            }

            swaps++;
            compares++;
        }

        while (i < l) {
            tab[k++] = left[i++];
            swaps++;
        }

        while (j < r) {
            tab[k++] = right[j++];
            swaps++;
        }
    }
}
