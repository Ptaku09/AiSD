import java.util.Random;

public class QuickSort {
    private static int compares = 0;
    private static int swaps = 0;

    public static void sort(int[] tab) {
        quickSort(tab, 0, tab.length);

        System.out.println("Quick sort: ");
        System.out.println("Compares: " + compares);
        System.out.println("Swaps: " + swaps);
        System.out.println();
    }

    private static void quickSort(int[] tab, int startIndex, int endIndex) {
        if (endIndex - startIndex > 1) {
            int partition = partition(tab, startIndex, endIndex);
            quickSort(tab, startIndex, partition);
            quickSort(tab, partition + 1, endIndex);
        }
    }

    private static int partition(int[] tab, int nFrom, int nTo) {
        Random random = new Random();
        int rnd = nFrom + random.nextInt(nTo - nFrom);
        swap(tab, nFrom, rnd);

        int value = tab[nFrom];
        int indexBigger = nFrom + 1;
        int indexLower = nTo - 1;

        do {
            while (indexBigger <= indexLower && tab[indexBigger] <= value) {
                indexBigger++;
                compares++;
            }

            compares++;

            while (tab[indexLower] > value) {
                indexLower--;
                compares++;
            }

            compares++;

            if (indexBigger < indexLower)
                swap(tab, indexBigger, indexLower);
        } while (indexBigger < indexLower);

        swap(tab, indexLower, nFrom);
        return indexLower;
    }

    private static void swap(int[] tab, int left, int right) {
        if (left != right) {
            int temp = tab[left];
            tab[left] = tab[right];
            tab[right] = temp;

            swaps += 3;
        }
    }
}
