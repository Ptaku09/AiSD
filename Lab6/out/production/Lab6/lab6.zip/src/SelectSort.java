public class SelectSort {
    public static void sort(int[] tab) {
        int compares = 0;
        int swaps = 0;

        for (int i = 0; i < tab.length - 1; i++) {
            int smallest = i;

            for (int j = i + 1; j < tab.length; j++) {
                if (tab[j] < tab[smallest])
                    smallest = j;

                compares++;
            }

            int temp = tab[smallest];
            tab[smallest] = tab[i];
            tab[i] = temp;
            swaps += 3;
        }

        System.out.println("Select sort: ");
        System.out.println("Compares: " + compares);
        System.out.println("Swaps: " + swaps);
        System.out.println();
    }
}
