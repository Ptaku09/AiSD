public class Main {
    public static void main(String[] args) {
        Huffman huffman = new Huffman();
        huffman.encode("uasdasbdisabd hello o");
        huffman.decode();
    }
}
