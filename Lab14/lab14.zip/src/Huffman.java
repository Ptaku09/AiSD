import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

public class Huffman {
    static class Node {
        private final Character character;
        private final Node left;
        private final Node right;
        private int frequency;

        public Node(Character character, int frequency, Node left, Node right) {
            this.character = character;
            this.frequency = frequency;
            this.left = left;
            this.right = right;
        }

        public int getFrequency() {
            return frequency;
        }

        public void setFrequency(int frequency) {
            this.frequency = frequency;
        }

        public char getCharacter() {
            return character;
        }

        public Node getLeft() {
            return left;
        }

        public Node getRight() {
            return right;
        }
    }

    private final PriorityQueue<Node> priorityQueue;
    private final Map<Character, Integer> frequencyMap;
    private final Map<Character, String> encodingMap;
    private Node root;
    private String encoded;

    public Huffman() {
        this.frequencyMap = new HashMap<>();
        this.priorityQueue = new PriorityQueue<>(Comparator.comparingInt(Node::getFrequency));
        this.encodingMap = new HashMap<>();
        root = null;
        encoded = "";
    }

    public void encode(String text) {
        buildFrequencyMap(text);
        createNodes();
        buildPriorityTree();
        createCodes(root, "");
        displayEncodedText(text);
    }

    public void decode() {
        if (root.getLeft() == null && root.getRight() == null) {
            while (root.getFrequency() > 0) {
                System.out.print(root.getCharacter());
                root.setFrequency(root.getFrequency() - 1);
            }
        } else {
            int index = -1;

            while (index < encoded.length() - 1)
                index = decode(root, index);
        }
    }

    private int decode(Node root, int index) {
        if (root == null) return index;

        if (root.getLeft() == null && root.getRight() == null) {
            System.out.print(root.getCharacter());
            return index;
        }

        index++;

        root = encoded.charAt(index) == '0' ? root.getLeft() : root.getRight();
        index = decode(root, index);

        return index;
    }

    private void buildFrequencyMap(String text) {
        for (int i = 0; i < text.length(); i++) {
            char character = text.charAt(i);

            if (frequencyMap.containsKey(character))
                frequencyMap.put(character, frequencyMap.get(character) + 1);
            else
                frequencyMap.put(character, 1);
        }
    }

    private void createNodes() {
        for (Map.Entry<Character, Integer> entry : frequencyMap.entrySet())
            priorityQueue.add(new Node(entry.getKey(), entry.getValue(), null, null));
    }

    private void buildPriorityTree() {
        while (priorityQueue.size() > 1) {
            Node left = priorityQueue.poll();
            Node right = priorityQueue.poll();

            assert right != null;
            Node nodeToAdd = new Node(null, left.getFrequency() + right.getFrequency(), left, right);
            priorityQueue.add(nodeToAdd);
        }

        root = priorityQueue.poll();
    }

    private void createCodes(Node root, String string) {
        if (root == null) return;

        if (root.getLeft() == null && root.getRight() == null)
            encodingMap.put(root.getCharacter(), string.length() > 0 ? string : "0");

        createCodes(root.getLeft(), string + "0");
        createCodes(root.getRight(), string + "1");
    }

    private void displayEncodedText(String text) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < text.length(); i++) {
            char character = text.charAt(i);
            sb.append(encodingMap.get(character));
        }

        this.encoded = sb.toString();
        System.out.println(this.encoded);
    }
}
