public interface PeopleSorter {
    Person[] sort(Person[] tab);
}
