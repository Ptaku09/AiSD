public class Main {
    public static void main(String[] args) {
        RedBlackTree rbt = new RedBlackTree();

        //insert data
        rbt.insert(2);
        rbt.insert(3);
        rbt.insert(5);
        rbt.insert(12);
        rbt.insert(14);
        rbt.insert(1);

        System.out.println("Find 2: " + rbt.find(2));
        System.out.println("Find 123: " + rbt.find(123));
        System.out.println();

        System.out.println("In order walk:");
        rbt.inOrderWalk();
        System.out.printf("%n%n");

        System.out.println("Display by level:");
        rbt.displayByLevel();
        System.out.printf("%n%n");

        System.out.println("Height: " + rbt.getHeight());
        System.out.println("Left subtree height: " + rbt.getLeftSubtreeHeight());
        System.out.println("Right subtree height: " + rbt.getRightSubtreeHeight());
        System.out.println("Number of nodes: " + rbt.getNumberOfNodes());
        System.out.println("Left subtree number of nodes: " + rbt.getLeftSubtreeNumberOfNodes());
        System.out.println("Number of nodes: " + rbt.getRightSubtreeNumberOfNodes());
        System.out.println();

        rbt.setSubtreeHeightsForEachNode();
        rbt.setSubtreeNumberOfNodesForEachNode();

        System.out.println("In order walk with all node data:");
        System.out.println("Template -> (value, color, left subtree height, right subtree height, left subtree number of nodes, right subtree number of nodes)");
        rbt.inOrderWalkWithAllData();
    }
}
