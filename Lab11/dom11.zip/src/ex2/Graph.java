package ex2;

public interface Graph {
    void addVertex(int v);

    void addEdge(int v1, int v2);

    void showData();
}
