package ex2;

public class GraphMatrix {
    private final int[][] edges;
    private final int[] vertices;

    public GraphMatrix(int n) {
        edges = new int[n][n];
        vertices = new int[n];
    }

    public void addVertex(int v) {
        int i = 0;

        while (i < vertices.length && vertices[i] != 0)
            i++;

        if (i == vertices.length) return;

        vertices[i] = v;
    }

    public void addEdge(int x, int y) {
        int i = 0;
        int j = 0;

        while (i < vertices.length && vertices[i] != x)
            i++;

        while (j < vertices.length && vertices[j] != y)
            j++;

        if (i == vertices.length || j == vertices.length) return;

        edges[i][j] = 1;
        edges[j][i] = 1;
    }

    public void showData() {
        System.out.print("v   ");

        for (int j : vertices) {
            System.out.print(j + " ");
        }

        System.out.println();

        for (int i = 0; i < edges.length; i++) {
            System.out.print(vertices[i] + " | ");

            for (int j = 0; j < edges.length; j++) {
                System.out.print(edges[i][j] + " ");
            }
            System.out.println();
        }
    }
}
