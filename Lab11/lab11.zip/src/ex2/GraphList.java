package ex2;

import java.util.ArrayList;
import java.util.List;

public class GraphList {
    private final List<List<Integer>> edges;
    private final int[] vertices;

    public GraphList(int n) {
        edges = new ArrayList<>();
        vertices = new int[n];
    }

    public void addVertex(int v) {
        List<Integer> list = new ArrayList<>();
        list.add(v);
        edges.add(list);
    }

    public void addEdge(int x, int y) {
        int i = 0;
        int j = 0;

        while (i < edges.size() && edges.get(i).get(0) != x)
            i++;

        while (j < edges.size() && edges.get(j).get(0) != y)
            j++;

        if (i == edges.size() || j == edges.size()) return;

        edges.get(i).add(y);
        edges.get(j).add(x);
    }

    public void showData() {
        System.out.print("v   ");

        for (List<Integer> list : edges) {
            for (int j : list) {
                System.out.print(j + " ");
            }
        }

        System.out.println();

        for (int i = 0; i < edges.size(); i++) {
            System.out.print(edges.get(i).get(0) + " | ");

            for (int j = 1; j < edges.get(i).size(); j++) {
                System.out.print(edges.get(i).get(j) + " ");
            }
            System.out.println();
        }
    }
}
