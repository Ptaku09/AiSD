package ex2;

public class Main2 {
    public static void main(String[] args) {
        GraphMatrix graphMatrix = new GraphMatrix(5);
        graphMatrix.addVertex(4);
        graphMatrix.addVertex(1);
        graphMatrix.addVertex(7);
        graphMatrix.addVertex(3);
        graphMatrix.addVertex(8);

        graphMatrix.addEdge(4, 7);
        graphMatrix.addEdge(1, 3);
        graphMatrix.addEdge(8, 4);
        graphMatrix.addEdge(7, 3);

        graphMatrix.showData();
    }
}
