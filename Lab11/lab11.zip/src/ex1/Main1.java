package ex1;

public class Main1 {
    public static void main(String[] args) {
        System.out.println("ArraySet");
        ArraySet arraySet = new ArraySet(5);

        arraySet.makeSet();
        arraySet.union(1, 2);
        arraySet.union(2, 3);
        arraySet.union(0, 4);
        arraySet.showData();

        System.out.println();

        System.out.println("TreeSet");

        Node[] nodes = new Node[5];

        for (int i = 0; i < nodes.length; i++) {
            nodes[i] = new Node(i);
        }

        TreeSet treeSet = new TreeSet(nodes);

        for (int i = 0; i < nodes.length; i++) {
            treeSet.makeSet(treeSet.getNodes()[i]);
        }

        treeSet.union(treeSet.getNodes()[0], treeSet.getNodes()[1]);
        treeSet.union(treeSet.getNodes()[3], treeSet.getNodes()[4]);
        treeSet.union(treeSet.getNodes()[4], treeSet.getNodes()[1]);
        treeSet.showData();
    }
}
