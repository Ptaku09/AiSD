package ex1;

public class TreeSet {
    private final Node[] nodes;

    public TreeSet(Node[] nodes) {
        this.nodes = nodes;
    }

    public void makeSet(Node node) {
        node.parent = node;
        node.rank = 0;
    }

    public void union(Node x, Node y) {
        link(findSet(x), findSet(y));
    }

    public Node findSet(Node node) {
        if (node.parent != node) {
            node.parent = findSet(node.parent);
        }

        return node.parent;
    }

    private void link(Node x, Node y) {
        if (x.rank > y.rank) {
            y.parent = x;
        } else {
            x.parent = y;

            if (x.rank == y.rank) {
                y.rank++;
            }
        }
    }

    public void showData() {
        System.out.printf("%-8s", "parent: ");

        for (Node node : nodes) {
            System.out.print(node.parent.key + " ");
        }

        System.out.println();
        System.out.printf("%-8s", "rank: ");

        for (Node node : nodes) {
            System.out.print(node.rank + " ");
        }
    }

    public Node[] getNodes() {
        return nodes;
    }
}
