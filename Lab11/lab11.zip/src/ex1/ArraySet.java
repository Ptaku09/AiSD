package ex1;

public class ArraySet {
    private final int[] rep;
    private final int[] next;
    private final int[] last;

    public ArraySet(int n) {
        rep = new int[n];
        next = new int[n];
        last = new int[n];
    }

    public void makeSet() {
        for (int i = 0; i < rep.length; i++) {
            rep[i] = i;
            next[i] = -1;
            last[i] = i;
        }
    }

    public int findSet(int x) {
        return rep[x];
    }

    public void union(int x, int y) {
        int xRoot = findSet(x);
        int yRoot = findSet(y);

        if (xRoot == yRoot) {
            return;
        }

        while (next[y] != -1) {
            rep[y] = xRoot;
            y = next[y];
        }

        rep[y] = xRoot;
        last[xRoot] = y;
    }

    public void showData() {
        System.out.printf("%-6s", "rep: ");

        for (int j : rep) {
            System.out.print(j + " ");
        }

        System.out.println();
        System.out.printf("%-6s", "next: ");

        for (int j : next) {
            System.out.print(j + " ");
        }

        System.out.println();
        System.out.printf("%-6s", "last: ");

        for (int j : last) {
            System.out.print(j + " ");
        }

        System.out.println();
    }
}
