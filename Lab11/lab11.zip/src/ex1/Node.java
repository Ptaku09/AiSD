package ex1;

public class Node {
    int key;
    Node parent;
    int rank;

    public Node(int key) {
        this.key = key;
        this.parent = this;
        this.rank = 0;
    }
}
