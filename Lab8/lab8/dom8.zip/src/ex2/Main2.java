package ex2;

public class Main2 {
    public static void main(String[] args) {
        new Test().runTests();
    }
}
