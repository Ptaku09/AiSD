package ex1;

public interface HashFunction {
    int hash(int el);
    void reset();
}
