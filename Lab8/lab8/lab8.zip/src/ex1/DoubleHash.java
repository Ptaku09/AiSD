package ex1;

public class DoubleHash implements HashFunction {
    private int i = 0;

    @Override
    public int hash(int el) {
        int code = 0;

        code += hashFunc(el);
        code += (i++) * hashFunc(el / 2);

        return code;
    }

    @Override
    public void reset() {
        i = 0;
    }

    private int hashFunc(int el) {
        int code = 0;

        while (Math.abs(el) > 0) {
            code += el % 10;
            el /= 10;
        }

        return code;
    }
}
