package ex1;

public class QuadraticHash implements HashFunction {
    private int i = 0;

    @Override
    public int hash(int el) {
        int code = 0;

        while (Math.abs(el) > 0) {
            code += el % 10;
            el /= 10;
        }

        return (int) (code + Math.pow(i++, 2));
    }

    @Override
    public void reset() {
        i = 0;
    }
}
