package ex2;

import DisjointSet.DisjointSet;
import Graph.Graph;
import Graph.Node;

import java.util.ArrayList;
import java.util.List;

public class MinimumSpanningTree {
    public static void kruskal(Graph graph) {
        List<Node> nodes = new ArrayList<>();
        DisjointSet ds = new DisjointSet(graph.getNodes().size());

        for (Node node : graph.getNodes()) {
            ds.makeSet(node.getValue());
        }
    }
}
