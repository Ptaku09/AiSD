package DisjointSet;

public interface MyDisjointSet {
    void makeSet(int x);

    int findSet(int x);

    void union(int x, int y);

    void showData();
}
