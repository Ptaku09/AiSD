package Graph;

public class Node {
    int value;
    boolean isVisited;

    public Node(int value) {
        this.value = value;
        this.isVisited = false;
    }

    public void visit() {
        this.isVisited = true;
    }

    public void unvisit() {
        this.isVisited = false;
    }

    public int getValue() {
        return value;
    }

    public boolean isVisited() {
        return isVisited;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}