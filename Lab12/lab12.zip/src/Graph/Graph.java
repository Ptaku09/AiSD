package Graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Graph implements MyGraph {
    private final Map<Node, List<Edge>> adjacencyList;

    public Graph() {
        adjacencyList = new HashMap<>();
    }

    @Override
    public void addVertex(Node v) {
        adjacencyList.putIfAbsent(v, new ArrayList<>());
    }

    @Override
    public void addEdge(Node v1, Node v2, int weight) {
        Edge edge1 = new Edge(v2, weight);
        Edge edge2 = new Edge(v1, weight);

        adjacencyList.get(v1).add(edge1);
        adjacencyList.get(v2).add(edge2);
    }

    @Override
    public void showData() {
        for (var entry : adjacencyList.entrySet()) {
            System.out.print(entry.getKey() + " | ");

            for (var value : entry.getValue())
                System.out.print(value + " ");

            System.out.println();
        }
    }

    @Override
    public List<Edge> getNeighbours(Node node) {
        return adjacencyList.get(node);
    }

    @Override
    public void resetVisited() {
        for (var entry : adjacencyList.entrySet())
            entry.getKey().unvisit();
    }

    public List<Node> getNodes() {
        return new ArrayList<>(adjacencyList.keySet());
    }
}
