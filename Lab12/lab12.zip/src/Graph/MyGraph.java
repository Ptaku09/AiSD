package Graph;

import java.util.List;

public interface MyGraph {
    void addVertex(Node v);

    void addEdge(Node v1, Node v2, int weight);

    void showData();

    List<Edge> getNeighbours(Node node);

    void resetVisited();
}
