package ex1;

import Graph.Edge;
import Graph.Graph;
import Graph.MyGraph;
import Graph.Node;

import java.util.ArrayList;
import java.util.LinkedList;

public class Search {
    public static void bfs(Graph graph, Node node) {
        if (node == null) return;

        LinkedList<Node> queue = new LinkedList<>();
        queue.add(node);

        while (!queue.isEmpty()) {
            Node current = queue.remove();

            if (current.isVisited()) continue;

            current.visit();
            System.out.print(current.getValue() + " ");

            ArrayList<Edge> neighboursLinks = (ArrayList<Edge>) graph.getNeighbours(current);

            if (neighboursLinks == null) continue;

            for (Edge neighbour : neighboursLinks)
                if (!neighbour.getDestination().isVisited())
                    queue.add(neighbour.getDestination());
        }

        System.out.println();
    }

    public static void dfs(MyGraph graph, Node node) {
        if (node == null) return;

        LinkedList<Node> stack = new LinkedList<>();
        stack.add(node);

        while (!stack.isEmpty()) {
            Node current = stack.removeLast();

            if (current.isVisited()) continue;

            current.visit();
            System.out.print(current.getValue() + " ");

            ArrayList<Edge> neighboursLinks = (ArrayList<Edge>) graph.getNeighbours(current);

            if (neighboursLinks == null) continue;

            for (int i = neighboursLinks.size() - 1; i >= 0; i--)
                if (!neighboursLinks.get(i).getDestination().isVisited())
                    stack.add(neighboursLinks.get(i).getDestination());
        }

        System.out.println();
    }
}
